# Novocaine Training

An installable web app version of the Novocaine Training prescription + tracking engine.
No build step, no npm install — this is plain HTML/CSS/JS and can be served as-is.

## Deploy to GitHub Pages

1. Create a new GitHub repository (or use an existing one).
2. Push these files to the repo root (or to a `docs/` folder — either works, just point
   Pages at whichever you use):
   ```
   git init
   git add .
   git commit -m "Novocaine Training web app"
   git branch -M main
   git remote add origin https://github.com/<you>/<repo>.git
   git push -u origin main
   ```
3. On GitHub: **Settings → Pages → Build and deployment → Source: Deploy from a branch**,
   then pick `main` and `/ (root)` (or `/docs`), and save.
4. GitHub gives you a URL like `https://<you>.github.io/<repo>/`. It can take a minute
   to go live the first time.

That's the whole deployment — there's no CI, no bundler, nothing else to configure.

## Installing it as an app

Once it's live on Pages (installability needs a real HTTPS origin — it won't offer to
install from a local file):

- **Android / Chrome / Edge (desktop or mobile):** open the URL, then use the browser's
  "Install app" / "Add to Home screen" prompt (often an icon in the address bar).
- **iPhone / Safari:** open the URL, tap Share → **Add to Home Screen**. iOS doesn't use
  the manifest's install prompt, but this achieves the same result — a standalone icon
  with no browser chrome.

## What's inside

- `index.html` — loads React 18 and Tailwind from CDN, plus `app.js`
- `app.js` — the entire app, compiled from JSX. No JSX/build tooling needed at runtime.
- `manifest.json` — name, icons, standalone display mode (what makes it "installable")
- `service-worker.js` — caches the app shell so it keeps working with no signal, which
  matters for a program built around being usable anywhere
- `icons/` — generated from the kettlebell artwork you provided, at every size iOS/
  Android/desktop actually ask for (16/32 favicon, 180 apple-touch, 192/512, plus a
  512 maskable variant with safe-zone padding for Android's adaptive icon mask)

## Data & privacy

All training data (setup, session history, training maxes) is stored in the browser's
`localStorage` on the device it's used on — nothing is sent anywhere, there's no backend.
That also means the data is per-browser/per-device; it won't sync between your phone and
a laptop unless you manually recreate the same setup on both.

## Notes on this build

This was ported from an interactive prototype built in Claude. Three things changed
specifically to make it dependency-free and installable, with no behavior changes:
- icons (previously `lucide-react`) are now small hand-drawn inline SVGs
- the Training Max chart (previously `recharts`) is now a ~30-line hand-rolled SVG chart
- storage (previously the Claude artifact `window.storage` API) is now `localStorage`

Everything else — every prescription rule, the mesocycle wave, the pace tables, the
category logic — is untouched. It was tested offline against the source data (category
table cross-checked row-by-row, VDOT paces checked against the published table) and
driven end-to-end in a real headless browser before being handed off here.
